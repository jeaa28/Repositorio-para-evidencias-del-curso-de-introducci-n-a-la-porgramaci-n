#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	
	char frase[] = "Hola clase";
	char *token = strtok(frase , " ");
	
	while (token !=NULL){
		printf("El token es:  %s\n", token);
		token = strtok(NULL,"");
	}
	
	
	//printf("Digite una frase: \n");
	
//do{
		//scanf("%s",frase);
		
	//	if(!feof(stdin)){
		//	printf("\n%s",frase);
		//}
	//}while(!feof(stdin));
	
	return 0;
}
