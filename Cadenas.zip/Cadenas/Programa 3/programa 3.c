#include <stdio.h>

int main(){
	int c,contar_a=0,contar_e=0,contar_i=0,contar_o=0,contar_u=0;
	
	printf("Digite una palabra posteriormente control z para iniciar el contador: \n");
	
	while(EOF != (c=getchar())){
		switch(c){
			case 'a': contar_a++;break;
			case 'e': contar_e++;break;
			case 'i': contar_i++;break;
			case 'o': contar_o++;break;
			case 'u': contar_u++;break;
		}
		putchar(c); 
	}
	
	printf("Vocal a: %i",contar_a);
	printf("\nVocal e: %i",contar_e);
	printf("\nVocal i: %i",contar_i);
	printf("\nVocal o: %i",contar_o);
	printf("\nVocal u: %i",contar_u);
	
	return 0;
}
