#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char palabra[20];
	

	printf("Digite la palabra a invertir: \n");
	
	scanf("%s",palabra);
	strrev(palabra);
	
	printf("La palabra invertida es: %s",palabra);
	
	
	
	return 0;
}
